﻿=== Vaporwave Hotline Black Plus Cursor Set ===

By: Foxxey (http://www.rw-designer.com/user/104284) anton.draftr@gmail.com

Download: http://www.rw-designer.com/cursor-set/vaporwave-hotline-black-plus

Author's description:

Hotline Black Cursor Pack, Vaporwave, Retrowave, Outrun, cyan to pink gradient, retro, whatever you want to call it, but with more cursors and animations! I also fixed some hotspots. If you need help or you have any suggestions let me know in the comments down below. Originally made by Babaluggy. Modified, animated and improved by me.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.